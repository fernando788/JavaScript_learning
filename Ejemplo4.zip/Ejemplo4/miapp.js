var cadena = "cadena de texto",
    inicio = 10,
    fin    = 15,
    subCadena = cadena.substring(inicio, fin);

console.log(subCadena);