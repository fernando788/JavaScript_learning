var cadena = "cadena de texto",
    separador = " ",
    arregloDeSubCadenas = cadena.split(separador);

console.log(arregloDeSubCadenas);