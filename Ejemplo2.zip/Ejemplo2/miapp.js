function name( fullname )
{    
    return fullname.firstname + fullname.lastname;
}

// Where there are objects...
var name1 = { firstname: "Fernando", lastname: "Araki"  };

const name2 = { firstname: "Fernando2", lastname: "Araki2"  };

console.log(
    name( name1 ),
    name( name2 )
);

function embed( run )
{
    return run();
}

var name3 = function() { return "Fernando3 Araki3"  };

const name4 = function() { return "Fernando4 Araki4" };

console.log(
    embed( name3 ),
    embed( name4 )
);