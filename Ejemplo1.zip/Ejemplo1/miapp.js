var auto = {
    marca: "volvo",
    velocidad: 160,
    motor: {
        tamanio: 2.0,
        marca: "bmw",
        combustible: "nafta",
        pistons:[
            { marcar: "BMW" },
            { marcar: "BMW2" }
        ]
    },
    drive: function(){ return "drive"; }
};

var array = [ 
    "string",
    100,
    [ "embed", 200 ],
    { auto: "ford" },
    function(){ return "drive"; }
];

console.log( auto.marca );
console.log( auto.velocidad );
